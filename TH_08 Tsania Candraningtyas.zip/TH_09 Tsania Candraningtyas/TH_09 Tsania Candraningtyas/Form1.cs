﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_09_Tsania_Candraningtyas
{
    public partial class Form1 : Form
    {
        DataTable dtproduct = new DataTable();
        DataTable dttshirt = new DataTable();
        DataTable dtshirt = new DataTable();
        DataTable dtpants = new DataTable();
        DataTable dtlongpants = new DataTable();
        DataTable dtshoes = new DataTable();
        DataTable dtJewelleries = new DataTable();
        string[] TShirt = { "T-shirt kerah bulat", "AIRism T-shirt", "V neck T- Shirt" };
        string[] Shirt = { "Polo Shirt Putih", "Polo Shirt Biru", "Polo Shirt Hijau" };
        string[] Pants = { "CelPen Putih", "CelPen Coklat", "CelPen Cargo" };
        string[] LongPants = { "Celana Cargo", "Celana Coklat", "Celana Hitam" };
        string[] Shoes = { "Sepatu Nike", "Sepatu NB", "Sepatu Adidas" };
        string[] Jewelleries = { "Jam Tangan", "Bracelet", "Necklace" };
        public Form1()
        {
            InitializeComponent();
            Panel1.Visible = true;
            Panel2.Visible = false;
        }

        private void jewelriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int a = 500000;
            int b = 290000;
            int c = 350000;
            lb_Nama1.Text = dtJewelleries.Rows[0][0].ToString();
            lb_Nama2.Text = dtJewelleries.Rows[1][0].ToString();
            lb_Nama3.Text = dtJewelleries.Rows[2][0].ToString();
            lb_Harga1.Text = "Rp. " + a.ToString("C2").Remove(0, 2).Remove(a.ToString().Length, 3) + ",-";
            lb_Harga2.Text = "Rp. " + b.ToString("C2").Remove(0, 2).Remove(b.ToString().Length, 3) + ",-";
            lb_Harga3.Text = "Rp. " + c.ToString("C2").Remove(0, 2).Remove(c.ToString().Length, 3) + ",-";
            //pb_1.Image = Jewelleries.Rows[0][0];
            string filenamenya = "E:\\Jewelleries\\Jam Tangan.jpeg";
            pb_1.Image = new Bitmap(filenamenya);
            string filenamenya2 = "E:\\Jewelleries\\Bracelet.jpeg";
            pb_3.Image = new Bitmap(filenamenya2);
            string filenamenya3 = "E:\\Jewelleries\\Necklace.jpeg";
            pb_2.Image = new Bitmap(filenamenya3);
            Panel1.Visible = true;
            Panel2.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dttshirt.Rows.Add("T-Shirt Kerah Bulat", "420000");
            dttshirt.Rows.Add("AIRism T-shirt", "290000");
            dttshirt.Rows.Add("V neck T-Shirt", "350000");
            DGV_Product.DataSource = dttshirt;
            dtshirt.Rows.Add("Polo Shirt Putih", "500000");
            dtshirt.Rows.Add("Polo Shirt Biru", "150000");
            dtshirt.Rows.Add("Polo Shirt Hijau", "190000");
            DGV_Product.DataSource = dtshirt;
            dtpants.Rows.Add("Celana Pendek Putih", "100000");
            dtpants.Rows.Add("Celana Pendek Coklat", "150000");
            dtpants.Rows.Add("Celana Pendek Cargo", "100000");
            DGV_Product.DataSource = dtpants;
            dtlongpants.Rows.Add("Celana Cargo", "300000");
            dtlongpants.Rows.Add("Celana Coklat", "250000");
            dtlongpants.Rows.Add("Celana Hitam", "150000");
            DGV_Product.DataSource = dtlongpants;
            dtshoes.Rows.Add("Sepatu Nike", "900000");
            dtshoes.Rows.Add("Sepatu NB", "1000000");
            dtshoes.Rows.Add("Sepatu Adidas", "950000");
            DGV_Product.DataSource = dtshoes;
            dtJewelleries.Rows.Add("Jam Tangan", "500000");
            dtJewelleries.Rows.Add("Bracelet", "290000");
            dtJewelleries.Rows.Add("Necklace", "350000");
            DGV_Product.DataSource = dtJewelleries;
            dtproduct.Columns.Add("Item");
            dtproduct.Columns.Add("Quantity");
            dtproduct.Columns.Add("Price");
            dtproduct.Columns.Add("Total");
            DGV_Product.DataSource = dtproduct;
            dttshirt.Columns.Add("Item Name");
            dttshirt.Columns.Add("Price");
            dtshirt.Columns.Add("Item Name");
            dtshirt.Columns.Add("Price");
            dtpants.Columns.Add("Item Name");
            dtpants.Columns.Add("Price");
            dtlongpants.Columns.Add("Item Name");
            dtlongpants.Columns.Add("Price");
            dtshoes.Columns.Add("Item Name");
            dtshoes.Columns.Add("Price");
            dtJewelleries.Columns.Add("Item Name");
            dtJewelleries.Columns.Add("Price");
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int z = 420000;
            int v = 290000;
            int x = 350000;
            lb_Nama1.Text = dttshirt.Rows[0][0].ToString();
            lb_Nama2.Text = dttshirt.Rows[1][0].ToString();
            lb_Nama3.Text = dttshirt.Rows[2][0].ToString();
            lb_Harga1.Text = "Rp. " + z;
            lb_Harga2.Text = "Rp. " + v.ToString("C2").Remove(0, 2).Remove(v.ToString().Length, 3) + ",-";
            lb_Harga3.Text = "Rp. " + x.ToString("C2").Remove(0, 2).Remove(x.ToString().Length, 3) + ",-";
            string filenamenya = "E:\\T-Shirt\\T-shirt kerah bulat.jpeg";
            pb_1.Image = new Bitmap(filenamenya);
            string filenamenya2 = "E:\\T-Shirt\\AIRism T-shirt.jpeg";
            pb_3.Image = new Bitmap(filenamenya2);
            string filenamenya3 = "E:\\T-Shirt\\V neck T- Shirt.jpeg";
            pb_2.Image = new Bitmap(filenamenya3);
            Panel1.Visible = true;
            Panel2.Visible = false;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int h = 500000;
            int f = 150000;
            int g = 190000;
            lb_Nama1.Text = dtshirt.Rows[0][0].ToString();
            lb_Nama2.Text = dtshirt.Rows[1][0].ToString();
            lb_Nama3.Text = dtshirt.Rows[2][0].ToString();
            lb_Harga1.Text = "Rp. " + h.ToString("C2").Remove(0, 2).Remove(h.ToString().Length, 3) + ",-";
            lb_Harga2.Text = "Rp. " + f.ToString("C2").Remove(0, 2).Remove(f.ToString().Length, 3) + ",-";
            lb_Harga3.Text = "Rp. " + g.ToString("C2").Remove(0, 2).Remove(g.ToString().Length, 3) + ",-";
            string filenamenya = "E:\\Shirt\\Polo Shirt Putih.jpeg";
            pb_1.Image = new Bitmap(filenamenya);
            string filenamenya2 = "E:\\Shirt\\Polo Shirt Biru.jpeg";
            pb_3.Image = new Bitmap(filenamenya2);
            string filenamenya3 = "E:\\Shirt\\Polo Shirt Hijau.jpeg";
            pb_2.Image = new Bitmap(filenamenya3);
            Panel1.Visible = true;
            Panel2.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = 100000;
            int j = 150000;
            int k = 100000;
            lb_Nama1.Text = dtpants.Rows[0][0].ToString();
            lb_Nama2.Text = dtpants.Rows[1][0].ToString();
            lb_Nama3.Text = dtpants.Rows[2][0].ToString();
            lb_Harga1.Text = "Rp. " + i.ToString("C2").Remove(0, 2).Remove(i.ToString().Length, 3) + ",-";
            lb_Harga2.Text = "Rp. " + j.ToString("C2").Remove(0, 2).Remove(j.ToString().Length, 3) + ",-";
            lb_Harga3.Text = "Rp. " + k.ToString("C2").Remove(0, 2).Remove(k.ToString().Length, 3) + ",-";
            string filenamenya = "E:\\Pants\\CelPen Putih.jpeg";
            pb_1.Image = new Bitmap(filenamenya);
            string filenamenya2 = "E:\\Pants\\CelPen Coklat.jpeg";
            pb_3.Image = new Bitmap(filenamenya2);
            string filenamenya3 = "E:\\Pants\\CelPen Cargo.jpeg";
            pb_2.Image = new Bitmap(filenamenya3);
            Panel1.Visible = true;
            Panel2.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int l = 300000;
            int m = 250000;
            int n = 150000;
            lb_Nama1.Text = dtlongpants.Rows[0][0].ToString();
            lb_Nama2.Text = dtlongpants.Rows[1][0].ToString();
            lb_Nama3.Text = dtlongpants.Rows[2][0].ToString();
            lb_Harga1.Text = "Rp. " + l.ToString("C2").Remove(0, 2).Remove(l.ToString().Length, 3) + ",-";
            lb_Harga2.Text = "Rp. " + m.ToString("C2").Remove(0, 2).Remove(m.ToString().Length, 3) + ",-";
            lb_Harga3.Text = "Rp. " + n.ToString("C2").Remove(0, 2).Remove(n.ToString().Length, 3) + ",-";
            string filenamenya = "E:\\Long Pants\\Celana Cargo.jpeg";
            pb_1.Image = new Bitmap(filenamenya);
            string filenamenya2 = "E:\\Long Pants\\Celana Coklat.jpeg";
            pb_3.Image = new Bitmap(filenamenya2);
            string filenamenya3 = "E:\\Long Pants\\Celana Hitam.jpeg";
            pb_2.Image = new Bitmap(filenamenya3);
            Panel1.Visible = true;
            Panel2.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int o = 900000;
            int p = 1000000;
            int q = 950000;
            lb_Nama1.Text = dtshoes.Rows[0][0].ToString();
            lb_Nama2.Text = dtshoes.Rows[1][0].ToString();
            lb_Nama3.Text = dtshoes.Rows[2][0].ToString();
            lb_Harga1.Text = "Rp. " + o.ToString("C2").Remove(0, 2).Remove(o.ToString().Length, 3) + ",-";
            lb_Harga2.Text = "Rp. " + p.ToString("C2").Remove(0, 2).Remove(p.ToString().Length, 3) + ",-";
            lb_Harga3.Text = "Rp. " + q.ToString("C2").Remove(0, 2).Remove(q.ToString().Length, 3) + ",-";
            string filenamenya = "E:\\Shoes\\Sepatu Nike.jpeg";
            pb_1.Image = new Bitmap(filenamenya);
            string filenamenya2 = "E:\\Shoes\\Sepatu NB.jpeg";
            pb_3.Image = new Bitmap(filenamenya2);
            string filenamenya3 = "E:\\Shoes\\Sepatu Adidas.jpeg";
            pb_2.Image = new Bitmap(filenamenya3);
            Panel1.Visible = true;
            Panel2.Visible = false;
        }
        int quantitykerahbulat = 0;
        decimal totalhargakerahbulat = 0;
        private void bt_Tshirt1_Click_1(object sender, EventArgs e)
        {
            decimal harga = 420000;
            quantitykerahbulat++;
            totalhargakerahbulat = harga * quantitykerahbulat;
            bool ada = false;

            foreach (DataGridViewRow row in DGV_Product.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Nama1.Text)
                {
                    row.Cells[1].Value = quantitykerahbulat;
                    row.Cells[3].Value = TotalHargaBarang(totalhargakerahbulat);
                    ada = true;
                    break;
                }
            }
            if (ada == false)
            {
                dttshirt.Rows.Add("T-Shirt Kerah Bulat", quantitykerahbulat, ConvertToRp(harga), TotalHargaBarang(totalhargakerahbulat));
                dttshirt.Rows[dttshirt.Rows.Count - 1]["Total"] = totalhargakerahbulat;
            }
            UpdateTotalPrice();
            UpdateSubTotal();

        }
        int quantityAlRism = 0;
        decimal totalHargaAlRism = 0;
        private void bt_Tshirt2_Click(object sender, EventArgs e)
        {
            decimal harga = 150000;
            quantityAlRism++;
            totalHargaAlRism = harga * quantityAlRism;
            bool ada = false;

            foreach (DataGridViewRow row in DGV_Product.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Nama2.Text)
                {
                    row.Cells[1].Value = quantityAlRism;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaAlRism);
                    ada = true;
                    break;
                }
            }

            if (ada == false)
            {
                dttshirt.Rows.Add("AlRism T-Shirt", quantityAlRism, ConvertToRp(harga), TotalHargaBarang(totalHargaAlRism));
                dttshirt.Rows[dttshirt.Rows.Count - 1]["Total"] = totalHargaAlRism;
            }
            UpdateTotalPrice();
            UpdateSubTotal();

        }
        int quantityVNeck = 0;
        decimal totalHargaVNeck = 0;
        private void bt_Tshirt3_Click(object sender, EventArgs e)
        {
            decimal harga = 150000;
            quantityVNeck++;
            totalHargaVNeck = harga * quantityVNeck;

            bool ada = false;

            foreach (DataGridViewRow row in DGV_Product.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Nama3.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityVNeck;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaVNeck);
                    ada = true;
                    break;
                }
            }

            if (ada == false)
            {
                dttshirt.Rows.Add("T-Shirt VNeck", quantityVNeck, ConvertToRp(harga), TotalHargaBarang(totalHargaVNeck));
                dttshirt.Rows[dttshirt.Rows.Count - 1]["Total"] = totalHargaVNeck;
            }
            UpdateTotalPrice();
            UpdateSubTotal();

        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Panel1.Visible = false;
            Panel2.Visible = true;
        }
        private void UpdateTotalPrice()
        {
            decimal totalPrice = 0m;
            foreach (DataGridViewRow row in DGV_Product.Rows)
            {
                if (row.Index != DGV_Product.Rows.Count - 1 && row.Cells["Total"].Value != null)
                {
                    decimal rowTotal = 0m;
                    if (Decimal.TryParse(row.Cells["Total"].Value.ToString(), out rowTotal))
                    {
                        totalPrice += rowTotal;
                    }
                    tb_Total.Text = totalPrice.ToString("C");
                }
            }
        }
        public void UpdateSubTotal()
        {
            decimal totalHarga = 0m;
            foreach (DataGridViewRow row in DGV_Product.Rows)
            {
                if (row.Index != DGV_Product.Rows.Count - 1 && row.Cells["Total"].Value != null)
                {
                    decimal rowTotal = 0m;
                    if (Decimal.TryParse(row.Cells["Total"].Value.ToString(), out rowTotal))
                    {
                        decimal hargaItem = rowTotal / 1.1m;
                        totalHarga += hargaItem;
                    }
                }
            }
            tb_Subtot.Text = totalHarga.ToString("C");
        }
        public string ConvertToRp(decimal harga)
        {
            string convert = "Rp." + harga.ToString("C2").Remove(harga.ToString().Length, 3) + ",-";
            return convert;
        }
        public string TotalHargaBarang(decimal totalHarga)
        {
            return ConvertToRp(totalHarga);
        }
    }
}