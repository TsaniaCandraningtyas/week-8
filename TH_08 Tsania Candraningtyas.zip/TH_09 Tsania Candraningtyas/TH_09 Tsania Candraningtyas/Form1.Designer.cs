﻿namespace TH_09_Tsania_Candraningtyas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DGV_Product = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_Subtot = new System.Windows.Forms.TextBox();
            this.tb_Total = new System.Windows.Forms.TextBox();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.lb_Harga3 = new System.Windows.Forms.Label();
            this.lb_Nama3 = new System.Windows.Forms.Label();
            this.lb_Harga2 = new System.Windows.Forms.Label();
            this.lb_Nama2 = new System.Windows.Forms.Label();
            this.lb_Harga1 = new System.Windows.Forms.Label();
            this.lb_Nama1 = new System.Windows.Forms.Label();
            this.bt_Tshirt3 = new System.Windows.Forms.Button();
            this.bt_Tshirt2 = new System.Windows.Forms.Button();
            this.bt_Tshirt1 = new System.Windows.Forms.Button();
            this.pb_3 = new System.Windows.Forms.PictureBox();
            this.pb_2 = new System.Windows.Forms.PictureBox();
            this.pb_1 = new System.Windows.Forms.PictureBox();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.bt_AddToCart = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tb_ItemPrice = new System.Windows.Forms.TextBox();
            this.tb_ItemName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Product)).BeginInit();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_1)).BeginInit();
            this.Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(799, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelriesToolStripMenuItem
            // 
            this.jewelriesToolStripMenuItem.Name = "jewelriesToolStripMenuItem";
            this.jewelriesToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.jewelriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelriesToolStripMenuItem.Click += new System.EventHandler(this.jewelriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // DGV_Product
            // 
            this.DGV_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Product.Location = new System.Drawing.Point(502, 36);
            this.DGV_Product.Name = "DGV_Product";
            this.DGV_Product.Size = new System.Drawing.Size(286, 232);
            this.DGV_Product.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(509, 292);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sub Total";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(509, 318);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Total";
            // 
            // tb_Subtot
            // 
            this.tb_Subtot.Location = new System.Drawing.Point(589, 292);
            this.tb_Subtot.Name = "tb_Subtot";
            this.tb_Subtot.Size = new System.Drawing.Size(199, 20);
            this.tb_Subtot.TabIndex = 4;
            // 
            // tb_Total
            // 
            this.tb_Total.Location = new System.Drawing.Point(589, 318);
            this.tb_Total.Name = "tb_Total";
            this.tb_Total.Size = new System.Drawing.Size(199, 20);
            this.tb_Total.TabIndex = 5;
            // 
            // Panel1
            // 
            this.Panel1.Controls.Add(this.lb_Harga3);
            this.Panel1.Controls.Add(this.lb_Nama3);
            this.Panel1.Controls.Add(this.lb_Harga2);
            this.Panel1.Controls.Add(this.lb_Nama2);
            this.Panel1.Controls.Add(this.lb_Harga1);
            this.Panel1.Controls.Add(this.lb_Nama1);
            this.Panel1.Controls.Add(this.bt_Tshirt3);
            this.Panel1.Controls.Add(this.bt_Tshirt2);
            this.Panel1.Controls.Add(this.bt_Tshirt1);
            this.Panel1.Controls.Add(this.pb_3);
            this.Panel1.Controls.Add(this.pb_2);
            this.Panel1.Controls.Add(this.pb_1);
            this.Panel1.Location = new System.Drawing.Point(12, 36);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(471, 297);
            this.Panel1.TabIndex = 6;
            // 
            // lb_Harga3
            // 
            this.lb_Harga3.AutoSize = true;
            this.lb_Harga3.Location = new System.Drawing.Point(344, 218);
            this.lb_Harga3.Name = "lb_Harga3";
            this.lb_Harga3.Size = new System.Drawing.Size(36, 13);
            this.lb_Harga3.TabIndex = 13;
            this.lb_Harga3.Text = "Harga";
            // 
            // lb_Nama3
            // 
            this.lb_Nama3.AutoSize = true;
            this.lb_Nama3.Location = new System.Drawing.Point(344, 196);
            this.lb_Nama3.Name = "lb_Nama3";
            this.lb_Nama3.Size = new System.Drawing.Size(72, 13);
            this.lb_Nama3.TabIndex = 12;
            this.lb_Nama3.Text = "Nama Produk";
            // 
            // lb_Harga2
            // 
            this.lb_Harga2.AutoSize = true;
            this.lb_Harga2.Location = new System.Drawing.Point(203, 218);
            this.lb_Harga2.Name = "lb_Harga2";
            this.lb_Harga2.Size = new System.Drawing.Size(36, 13);
            this.lb_Harga2.TabIndex = 11;
            this.lb_Harga2.Text = "Harga";
            // 
            // lb_Nama2
            // 
            this.lb_Nama2.AutoSize = true;
            this.lb_Nama2.Location = new System.Drawing.Point(203, 196);
            this.lb_Nama2.Name = "lb_Nama2";
            this.lb_Nama2.Size = new System.Drawing.Size(72, 13);
            this.lb_Nama2.TabIndex = 10;
            this.lb_Nama2.Text = "Nama Produk";
            // 
            // lb_Harga1
            // 
            this.lb_Harga1.AutoSize = true;
            this.lb_Harga1.Location = new System.Drawing.Point(54, 218);
            this.lb_Harga1.Name = "lb_Harga1";
            this.lb_Harga1.Size = new System.Drawing.Size(36, 13);
            this.lb_Harga1.TabIndex = 9;
            this.lb_Harga1.Text = "Harga";
            // 
            // lb_Nama1
            // 
            this.lb_Nama1.AutoSize = true;
            this.lb_Nama1.Location = new System.Drawing.Point(54, 196);
            this.lb_Nama1.Name = "lb_Nama1";
            this.lb_Nama1.Size = new System.Drawing.Size(72, 13);
            this.lb_Nama1.TabIndex = 6;
            this.lb_Nama1.Text = "Nama Produk";
            // 
            // bt_Tshirt3
            // 
            this.bt_Tshirt3.Location = new System.Drawing.Point(345, 238);
            this.bt_Tshirt3.Name = "bt_Tshirt3";
            this.bt_Tshirt3.Size = new System.Drawing.Size(71, 21);
            this.bt_Tshirt3.TabIndex = 5;
            this.bt_Tshirt3.Text = "Add to Cart";
            this.bt_Tshirt3.UseVisualStyleBackColor = true;
            this.bt_Tshirt3.Click += new System.EventHandler(this.bt_Tshirt3_Click);
            // 
            // bt_Tshirt2
            // 
            this.bt_Tshirt2.Location = new System.Drawing.Point(204, 241);
            this.bt_Tshirt2.Name = "bt_Tshirt2";
            this.bt_Tshirt2.Size = new System.Drawing.Size(71, 21);
            this.bt_Tshirt2.TabIndex = 4;
            this.bt_Tshirt2.Text = "Add to Cart";
            this.bt_Tshirt2.UseVisualStyleBackColor = true;
            this.bt_Tshirt2.Click += new System.EventHandler(this.bt_Tshirt2_Click);
            // 
            // bt_Tshirt1
            // 
            this.bt_Tshirt1.Location = new System.Drawing.Point(54, 240);
            this.bt_Tshirt1.Name = "bt_Tshirt1";
            this.bt_Tshirt1.Size = new System.Drawing.Size(71, 21);
            this.bt_Tshirt1.TabIndex = 3;
            this.bt_Tshirt1.Text = "Add to Cart";
            this.bt_Tshirt1.UseVisualStyleBackColor = true;
            this.bt_Tshirt1.Click += new System.EventHandler(this.bt_Tshirt1_Click_1);
            // 
            // pb_3
            // 
            this.pb_3.Location = new System.Drawing.Point(166, 17);
            this.pb_3.Name = "pb_3";
            this.pb_3.Size = new System.Drawing.Size(138, 165);
            this.pb_3.TabIndex = 2;
            this.pb_3.TabStop = false;
            // 
            // pb_2
            // 
            this.pb_2.Location = new System.Drawing.Point(310, 17);
            this.pb_2.Name = "pb_2";
            this.pb_2.Size = new System.Drawing.Size(136, 165);
            this.pb_2.TabIndex = 1;
            this.pb_2.TabStop = false;
            // 
            // pb_1
            // 
            this.pb_1.Location = new System.Drawing.Point(18, 17);
            this.pb_1.Name = "pb_1";
            this.pb_1.Size = new System.Drawing.Size(142, 165);
            this.pb_1.TabIndex = 0;
            this.pb_1.TabStop = false;
            // 
            // Panel2
            // 
            this.Panel2.Controls.Add(this.bt_AddToCart);
            this.Panel2.Controls.Add(this.button1);
            this.Panel2.Controls.Add(this.tb_ItemPrice);
            this.Panel2.Controls.Add(this.tb_ItemName);
            this.Panel2.Controls.Add(this.label5);
            this.Panel2.Controls.Add(this.label4);
            this.Panel2.Controls.Add(this.label3);
            this.Panel2.Controls.Add(this.pictureBox1);
            this.Panel2.Location = new System.Drawing.Point(13, 340);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(366, 272);
            this.Panel2.TabIndex = 7;
            // 
            // bt_AddToCart
            // 
            this.bt_AddToCart.Location = new System.Drawing.Point(163, 181);
            this.bt_AddToCart.Name = "bt_AddToCart";
            this.bt_AddToCart.Size = new System.Drawing.Size(93, 23);
            this.bt_AddToCart.TabIndex = 7;
            this.bt_AddToCart.Text = "Add to Cart";
            this.bt_AddToCart.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(131, 16);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Upload";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // tb_ItemPrice
            // 
            this.tb_ItemPrice.Location = new System.Drawing.Point(146, 139);
            this.tb_ItemPrice.Name = "tb_ItemPrice";
            this.tb_ItemPrice.Size = new System.Drawing.Size(142, 20);
            this.tb_ItemPrice.TabIndex = 5;
            // 
            // tb_ItemName
            // 
            this.tb_ItemName.Location = new System.Drawing.Point(146, 88);
            this.tb_ItemName.Name = "tb_ItemName";
            this.tb_ItemName.Size = new System.Drawing.Size(142, 20);
            this.tb_ItemName.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(143, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Item Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(143, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Item Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Upload Image";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(17, 50);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 208);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 632);
            this.Controls.Add(this.Panel2);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.tb_Total);
            this.Controls.Add(this.tb_Subtot);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DGV_Product);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Product)).EndInit();
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_1)).EndInit();
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView DGV_Product;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_Subtot;
        private System.Windows.Forms.TextBox tb_Total;
        private System.Windows.Forms.Panel Panel1;
        private System.Windows.Forms.Button bt_Tshirt3;
        private System.Windows.Forms.Button bt_Tshirt2;
        private System.Windows.Forms.Button bt_Tshirt1;
        private System.Windows.Forms.PictureBox pb_3;
        private System.Windows.Forms.PictureBox pb_2;
        private System.Windows.Forms.PictureBox pb_1;
        private System.Windows.Forms.Label lb_Nama1;
        private System.Windows.Forms.Label lb_Harga1;
        private System.Windows.Forms.Label lb_Harga3;
        private System.Windows.Forms.Label lb_Nama3;
        private System.Windows.Forms.Label lb_Harga2;
        private System.Windows.Forms.Label lb_Nama2;
        private System.Windows.Forms.Panel Panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bt_AddToCart;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tb_ItemPrice;
        private System.Windows.Forms.TextBox tb_ItemName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}

